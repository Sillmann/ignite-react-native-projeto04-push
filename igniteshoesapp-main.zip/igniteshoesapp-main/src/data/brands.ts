export const BRANDS = [
  { id: '1', name: 'Nike', image: require('../assets/brands/nike.png') },
  { id: '2', name: 'Adidas', image: require('../assets/brands/adidas.png') },
  { id: '3', name: 'Mizuno', image: require('../assets/brands/mizuno.png') },
  { id: '4', name: 'Puma', image: require('../assets/brands/puma.png') },
  { id: '5', name: 'Reebok', image: require('../assets/brands/reebok.png') },
];