export declare global {
  namespace ReactNavigation {
    interface RootParamList {
      cart: undefined;
      products: undefined;
      details: { productId: string };
    }
  }
}